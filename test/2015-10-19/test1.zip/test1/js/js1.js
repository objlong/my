window.onload = function  () {
	var aul = document.getElementsByTagName('ul')[0];
	var ali = document.getElementsByTagName('li');
	function ss (a) {
		timer = setInterval(function(){
		var lefts = parseInt(css(aul,'marginLeft'));
		aul.style.marginLeft = (lefts-4)+'px';
			if (lefts == -500*a) {
			clearInterval(timer);
			}

		},16)
	}

	ss(1)
	function css (obj,attr) {
		if (obj.currentStyle) {
			return obj.currentStyle[attr];
		}else{
			return getComputedStyle(obj)[attr];
		}
	}
}